#pragma once
#include "DDS/DDSListener.h"

/* Nephalem ����ӿ� */
class PublisherListener : public DDSListener
{

};